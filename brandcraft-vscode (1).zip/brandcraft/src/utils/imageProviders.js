// ─── Logo Image Generation — cascade across 4 providers ────────────────────
// Falls through providers in order; first success wins.

const IMAGE_API_KEY = process.env.REACT_APP_IMAGE_API_KEY;

// 1. Pollinations.ai — 100% free, no key, always available
async function tryPollinations(prompt) {
  const encoded = encodeURIComponent(
    prompt + ", logo design, vector art, clean white background, professional"
  );
  const url = `https://image.pollinations.ai/prompt/${encoded}?width=512&height=512&nologo=true&seed=${Math.floor(Math.random() * 99999)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Pollinations ${res.status}`);
  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// 2. getimg.ai (via local proxy)
async function tryGetimgAI(prompt) {
  const res = await fetch("/api/image", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      prompt,
      negative_prompt: "blurry, watermark, low quality, distorted, photo, realistic, text overlay",
      width: 512, height: 512, steps: 30, guidance: 8, output_format: "jpeg",
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`getimg.ai ${res.status}: ${data?.error?.message || JSON.stringify(data).slice(0, 100)}`);
  if (!data.image) throw new Error("getimg.ai: no image in response");
  return `data:image/jpeg;base64,${data.image}`;
}

// 3. Leonardo.ai — async polling
async function tryLeonardoAI(prompt) {
  const createRes = await fetch("https://cloud.leonardo.ai/api/rest/v1/generations", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${IMAGE_API_KEY}` },
    body: JSON.stringify({
      prompt,
      negative_prompt: "blurry, watermark, low quality, photo, realistic",
      modelId: "b24e16ff-06e3-43eb-8d33-4416c2d75876",
      width: 512, height: 512, num_images: 1, guidance_scale: 8, num_inference_steps: 30,
    }),
  });
  const createData = await createRes.json();
  if (!createRes.ok) throw new Error(`Leonardo ${createRes.status}: ${JSON.stringify(createData).slice(0, 100)}`);
  const genId = createData?.sdGenerationJob?.generationId;
  if (!genId) throw new Error("Leonardo: no generationId");

  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 2000));
    const pollRes = await fetch(`https://cloud.leonardo.ai/api/rest/v1/generations/${genId}`, {
      headers: { Authorization: `Bearer ${IMAGE_API_KEY}` },
    });
    const pollData = await pollRes.json();
    const gen = pollData?.generations_by_pk;
    if (gen?.status === "COMPLETE") {
      const imgUrl = gen.generated_images?.[0]?.url;
      if (!imgUrl) throw new Error("Leonardo: no image URL");
      return imgUrl;
    }
    if (gen?.status === "FAILED") throw new Error("Leonardo: generation failed");
  }
  throw new Error("Leonardo: timed out");
}

// 4. Stability AI
async function tryStabilityAI(prompt) {
  const res = await fetch("https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${IMAGE_API_KEY}` },
    body: JSON.stringify({
      text_prompts: [{ text: prompt, weight: 1 }, { text: "blurry, photo, watermark, low quality", weight: -1 }],
      cfg_scale: 8, height: 512, width: 512, samples: 1, steps: 30,
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Stability ${res.status}: ${data?.message || JSON.stringify(data).slice(0, 100)}`);
  if (!data.artifacts?.[0]?.base64) throw new Error("Stability: no image");
  return `data:image/png;base64,${data.artifacts[0].base64}`;
}

/**
 * Master cascade: tries all providers in order, returns first success
 */
export async function generateLogoImage(prompt, onStatus) {
  const providers = [
    { name: "Pollinations.ai (free)", fn: tryPollinations },
    { name: "getimg.ai",              fn: tryGetimgAI },
    { name: "Leonardo.ai",            fn: tryLeonardoAI },
    { name: "Stability AI",           fn: tryStabilityAI },
  ];
  const errors = [];
  for (const p of providers) {
    try {
      onStatus?.(`Trying ${p.name}…`);
      const result = await p.fn(prompt);
      onStatus?.(`✓ ${p.name}`);
      return result;
    } catch (e) {
      console.warn(`${p.name} failed:`, e.message);
      errors.push(`${p.name}: ${e.message}`);
    }
  }
  throw new Error(errors.join("\n"));
}
